#! /bin/bash

../icc3201-syscalls_tester/run-tests.sh $*


