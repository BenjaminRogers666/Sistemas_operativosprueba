//
// test program for the shell lab.
// run it in xv6 like this:
// $ testsh nsh
//

#include "types.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char* argv[])
{
  exit();
}